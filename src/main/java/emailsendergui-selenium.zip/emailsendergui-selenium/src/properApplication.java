import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

import java.util.Enumeration;
import java.util.Hashtable;

public class Main extends Application 
{ 
  
  @Override
  public void start(Stage primaryStage) {
        int width = 600;
        int height = 600;
        Pane root = new Pane();
        Scene scene = new Scene(root, width, height);
        Label providerLabel = new Label("პროვაიდერი: ");
        Label problemLabel = new Label("პრობლემა: ");
        Label startDateLabel = new Label("დაწყების თარიღი: ");
        Label startTimeLabel = new Label("დაწყების დრო: ");
        Label timeSeparator = new Label(":");
        ComboBox providerBox = new ComboBox();
        ComboBox problemBox = new ComboBox();
        Button button = new Button("Print");
        DatePicker startDate = new DatePicker();
        TextField startTimeH = new TextField();
        TextField startTimeM = new TextField();
        TextArea problemExample = new TextArea();

    
        String problemList[] = {"დეპოზიტები", "ფეიაუთები", "SMS"};
        Hashtable<String, String> providerList = new Hashtable<>();
        providerList.put("Bank of Georgia", "Support@gc.com");
        providerList.put("TBC(UFC)", "Ecommerce@ufc.com");
        Enumeration<String> keys = providerList.keys();
//        System.out.println(problemList);
        while (keys.hasMoreElements()){
            providerBox.getItems().addAll(keys.nextElement());
        }

        problemBox.getItems().addAll(problemList);

        EventHandler<ActionEvent> send = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

            }
        };



        providerLabel.setLayoutY(10);
        providerLabel.setLayoutX(10);
        problemLabel.setLayoutY(10);
        problemLabel.setLayoutX(300);
        startDateLabel.setLayoutY(50);
        startDateLabel.setLayoutX(10);
        startTimeLabel.setLayoutY(95);
        startTimeLabel.setLayoutX(10);
        timeSeparator.setLayoutX(170);
        timeSeparator.setLayoutY(90);
        providerBox.setLayoutX(120);
        providerBox.setLayoutY(10);
        problemBox.setLayoutY(10);
        problemBox.setLayoutX(400);
        button.setLayoutY(400);
        button.setLayoutX(10);
        startDate.setLayoutX(130);
        startDate.setLayoutY(50);
        startTimeH.setLayoutX(130);
        startTimeH.setLayoutY(90);
        startTimeH.setMaxWidth(30);
        startTimeH.setMinWidth(30);
        startTimeM.setMaxWidth(30);
        startTimeM.setMinWidth(30);
        startTimeM.setLayoutX(190);
        startTimeM.setLayoutY(90);
        problemExample.setLayoutX(10);
        problemExample.setLayoutY(150);



        root.getChildren().add(startDateLabel);
        root.getChildren().add(providerBox);
        root.getChildren().add(problemBox);
        root.getChildren().add(startTimeLabel);
        root.getChildren().add(providerLabel);
        root.getChildren().add(problemLabel);
        root.getChildren().add(startDate);
        root.getChildren().add(button);
        root.getChildren().add(timeSeparator);
        root.getChildren().add(startTimeH);
        root.getChildren().add(startTimeM);
        root.getChildren().add(problemExample);
        primaryStage.setScene(scene);
        primaryStage.setTitle("EmailSender");
        primaryStage.show();
  } 
    
  public static void main(String[] args) {
    launch(args);
  }
} 
